<?php
/**
 * This class for managing social authorization operations
 *
 * @author Hüseyin BABAL <turkiye.java@gmail.com>
 */

class SocialAuth
{
    /**
     * This is the factory of social networks' libraries
     * @static
     * @throws Exception
     * @param $type
     * @return EpiTwitter|Facebook|LinkedIn
     */
    public static function init( $type ) {
        switch ($type) {
            case 'twitter':
                if ( self::includeFiles( $type ) ) {
                    return new EpiTwitter( get_option( 'twitter_consumer_key' ), get_option( 'twitter_consumer_secret' ) );
                } else {
                    throw new Exception('Necessary library not found for ' . $type);
                }
                break;
            case 'facebook':
                if ( self::includeFiles( $type ) ) {
                    return new Facebook( array(
                            'appId' => get_option( 'facebook_consumer_key' ),
                            'secret' => get_option( 'facebook_consumer_secret' ) ) );
                } else {
                    throw new Exception( 'Necessary library not found for ' . $type );
                }
                break;
            case 'linkedin':
                if ( self::includeFiles( $type, 'OAuth.php' )) {
                    return new LinkedIn( get_option( 'linkedin_consumer_key' ),
                                         get_option( 'linkedin_consumer_secret' ),
                                         get_option( 'linkedin_consumer_callback_url' ) );
                } else {
                    throw new Exception( 'Necessary library not found for ' . $type );
                }
                break;
            case 'google':
                if ( self::includeFiles( $type ) ) {
                    return new LightOpenID();
                } else {
                    throw new Exception( 'Necessary library not found for ' . $type );
                }
                break;
            case 'yahoo':
                if ( self::includeFiles( $type ) ) {
                    return new LightOpenID( get_option( 'global_base_path' ) );
                } else {
                    throw new Exception( 'Necessary library not found for ' . $type );
                }
                break;
            default:
               throw new Exception( 'Couldn\'t initialized SocialAuth.Input parameter required' );
        }

    }

    /**
     * Include all files(for class including) under specified directory
     * @param string $path
     * @return void
     */
    private static function includeFiles( $path = '', $excluded = '' ) {
        $included = 0;
	/**
	If user use another plugin that use facebook, there can be conflict on facebook classes.
	Exceptions have been added for this reason
	**/

	/** Exceptions start **/ 
	if ( $path == 'facebook' && class_exists( 'FacebookApiException' )) {
		return 1;	
	}
	/** Exceptions end **/

        foreach ( glob( dirname( __FILE__ ) . '/' . $path . '/*.php' ) as $classes ) {
            $classPath = explode( "/", $classes );
            if ( $excluded != $classPath[2] ) {
                include_once( $classes );
                $included++;
            }
        }
        return $included;
    }

    /**
     * Sets session data
     * @static
     * @param string $key
     * @param bool $val
     * @return void
     */
    public static function setSessionData( $key = 'SocialAuth', $val = array() , $expire_day = 1) {
        setcookie( $key, serialize( $val ), intval($expire_day)*3600*24 );
    }

    /**
     * Gets stored session data
     * @static
     * @param string $key
     * @return mixed
     */
    public static function getSessionData( $key = 'SocialAuth' ) {
        return unserialize( $_COOKIE[$key] );
    }

    /**
     * Redirects to custom url
     * @param $url
     * @return void
     */
    public static function myRedirect($url) {
        echo "<meta http-equiv='refresh' content='0;url=$url' />";
    }
}
