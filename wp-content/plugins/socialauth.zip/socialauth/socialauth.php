<?php 
/*
Plugin Name: Social Auth
Plugin URI: http://www.omgphp.com
Description: Authorize your sign-in with social networks.
Version: 1.0
Author: Hüseyin BABAL
Author URI: http://www.omgphp.com
*/

define('SOCIAL_PLUGIN_URL', plugin_dir_url( __FILE__ ));
require_once dirname( __FILE__ ) . '/src/SocialAuth.php';

function socialauth_admin() {
    include( 'socialauth_admin.php' );
}

function socialauth_admin_actions() {
    add_options_page( 'Social Auth', 'Social Auth', 1, 'Social-Auth', 'socialauth_admin' );
}


function get_socialauth_login_area() {
    $login_html = false;
    global $current_user;
    if ( !is_user_logged_in() ) {
        ( strlen( get_option( "twitter_logo_url" ) ) > 0 )?($login_html .= '<a href="' . str_replace( "%7E", "~", $_SERVER["REQUEST_URI"]) . '?action=login&type=twitter"><img src="' . get_option( "twitter_logo_url" ) . '"/></a>'):( $login_html .= '' );
        ( strlen( get_option( "facebook_logo_url" ) ) > 0 )?($login_html .= '<a href="' . str_replace( "%7E", "~", $_SERVER["REQUEST_URI"]) . '?action=login&type=facebook"><img src="' . get_option( "facebook_logo_url" ) . '"/></a>'):( $login_html .= '' );
        ( strlen( get_option( "google_logo_url" ) ) > 0 )?($login_html .= '<a href="' . str_replace( "%7E", "~", $_SERVER["REQUEST_URI"]) . '?action=login&type=google"><img src="' . get_option( "google_logo_url" ) . '"/></a>'):( $login_html .= '' );
        ( strlen( get_option( "linkedin_logo_url" ) ) > 0 )?($login_html .= '<a href="' . str_replace( "%7E", "~", $_SERVER["REQUEST_URI"]) . '?action=login&type=linkedin"><img src="' . get_option( "linkedin_logo_url" ) . '"/></a>'):( $login_html .= '' );
        ( strlen( get_option( "yahoo_logo_url" ) ) > 0 )?($login_html .= '<a href="' . str_replace( "%7E", "~", $_SERVER["REQUEST_URI"]) . '?action=login&type=yahoo"><img src="' . get_option( "yahoo_logo_url" ) . '"/></a>'):( $login_html .= '' );
    }

    return $login_html;
}

function widget_socialauth($args) {
    extract($args);
    $options = get_option('widget_socialauth');
    if ( !is_array( $options ) ) {
    $options = array(
      'title' => 'My Widget Title'
      );
    }
    if ( !is_user_logged_in() ) {
        $html = '<h3 class="widget-title">' . $options["title"] . '</h3>';
        $html .= get_socialauth_login_area();
    } else {
        $html = get_socialauth_login_area();
    }

    echo $html;
}

function socialauth_init() {
    register_sidebar_widget( __('Social Auth'), 'widget_socialauth' );
    register_widget_control(   'Social Auth', 'socialauth_control' );
}

function socialauth_control() {
    $form_html = '';
    $options = get_option( 'widget_socialauth' );
    if ( !is_array( $options ) ) {
        $options = array( 'title' => 'My Widget Title' );
    }

    if ( $_POST['socialauth_submit'] ) {
        $options['title'] = htmlspecialchars( $_POST['socialauth_widget_title'] );
        update_option("widget_socialauth", $options);
    }

    $form_html .= '<p>
                       <label for="socialauth_widget_title">Widget Title: </label>
                       <input type="text" id="socialauth_widget_title" name="socialauth_widget_title" value="' . $options["title"] . '" />
                       <input type="hidden" id="socialauth_submit" name="socialauth_submit" value="1" />
                   </p>';
    echo $form_html;
}


function check_login_state() {
    $next_url = '';
    if ( empty( $_COOKIE['SocialAuth'] ) ) {
        //action = login, logout ; type = twitter, facebook, google, linkedin
        if ( !empty($_GET['action'] ) && $_GET['action'] == "login" ) {
            switch ( $_GET['type'] ) {
                case 'twitter':
                    //Initialize twitter by using factory pattern over main class(SocialAuth)
                    $twitterObj = SocialAuth::init( 'twitter' );
                    //Get login url according to configurations you specified in configs.php
                    $twitterLoginUrl = $twitterObj->getAuthenticateUrl(
                        null, array( 'oauth_callback' => get_option( 'twitter_callback_url' ) ) );
                    $next_url = $twitterLoginUrl;
                    break;
                case 'facebook':
                    //Initialize facebook by using factory pattern over main class(SocialAuth)
                    $facebookObj = SocialAuth::init( 'facebook' );
                    //Get login url according to configurations you specified in configs.php
                    $facebookLoginUrl = $facebookObj->getLoginUrl( array( 'scope' => get_option( 'facebook_permissions' ),
                                                                          'canvas' => 1,
                                                                          'fbconnect' => 0,
                                                                          'redirect_uri' => get_option( 'facebook_callback_url' ) ) );
                    $next_url = $facebookLoginUrl;
                    break;
                case 'google':
                    //Initialize google by using factory pattern over main class(SocialAuth)
                    $googleObj = SocialAuth::init( 'google' );
                    if (!$googleObj->mode) {
                            $googleObj->identity = 'https://www.google.com/accounts/o8/id';
                            $googleObj->required = array( 'namePerson/first', 'namePerson/last', 'contact/email' );
                            $googleObj->returnUrl = get_option( 'google_callback_url' );
                            //Get login url according to configurations you specified in configs.php and redirect to that url
                            $next_url = $googleObj->authUrl();
                    }
                    break;
                case 'linkedin':
                    //Initialize linkedin by using factory pattern over main class(SocialAuth)
                    $linkedinObj = SocialAuth::init( 'linkedin' );
                    $linkedinObj->getRequestToken();
                    $_SESSION['requestToken'] = serialize( $linkedinObj->request_token );
                    //Get login url according to configurations you specified in configs.php
                    $linkedinLoginUrl = $linkedinObj->generateAuthorizeUrl();
                    $next_url = $linkedinLoginUrl;
                    break;
                case 'yahoo':
                    $yahooObj = SocialAuth::init( 'yahoo' );
                    $yahooObj->identity = 'https://me.yahoo.com';
                    $yahooObj->required = array(
                                        'namePerson',
                                        'namePerson/first',
                                        'namePerson/last',
                                        'contact/email');

                    $yahooObj->returnUrl = get_option( 'yahoo_callback_url' );
                    //Get login url according to configurations you specified in configs.php and redirect to that url
                    $next_url = $yahooObj->authUrl();
                    break;
                default:
                    //If any login system found, warn user
                    echo "Invalid Login system";
            }
            SocialAuth::myRedirect($next_url);
            exit;
        }
    } else {
        if ( !empty($_GET['action'] ) && $_GET['action'] == "logout" ) {
            //If action is logout, just expire the cookie
            setcookie('SocialAuth', '', -3600);
            $next_url = get_option( 'global_base_path' );
            SocialAuth::myRedirect($next_url);
            exit;
        }
    }
}

function check_callback_state() {
    global $wpdb;
    if ( !empty( $_GET['type']) && $_GET['callback'] == true ) {
        $user_data = array();
        switch ( $_GET['type'] ) {
            case 'twitter':
                //Initialize twitter by using factory pattern over main class(SocialAuth)
                $twitterObj = SocialAuth::init( 'twitter' );

                $twitterObj->setToken( $_GET['oauth_token'] );
                $token = $twitterObj->getAccessToken();
                $twitterObj->setToken( $token->oauth_token, $token->oauth_token_secret );

                // save to cookies
                setcookie( 'oauth_token', $token->oauth_token );
                setcookie( 'oauth_token_secret', $token->oauth_token_secret );

                $twitterInfo= $twitterObj->get_accountVerify_credentials();

                $user_data = array(
                        'display_name' => $twitterInfo->name,
                        'user_email' => 't_' . $twitterInfo->screen_name . "@twitter.com"
                );
                break;
            case 'facebook':
                //Initialize facebook by using factory pattern over main class(SocialAuth)
                $facebookObj = SocialAuth::init( 'facebook' );
                $facebookInfo = $facebookObj->getUser();
                if ( $facebookInfo ) {
                  try {
                    $url = '';
                    //Check if any field value specified in configs.php
                    $fields = get_option( 'facebook_return_fields' );
                    if ( !empty( $fields ) ) {
                        $url = '?fields=' . $fields;
                    }
                    // Get detailed user info.
                    $facebookUserInfo = $facebookObj->api( '/me' . $url );

                    $user_data = array(
                        'display_name' => $facebookUserInfo['name'],
                        'user_email' => $facebookUserInfo['email']
                    );
                  } catch ( FacebookApiException $e ) {
                    error_log( $e );
                    $facebookInfo = null;
                  }
                }
                break;
            case 'google':
                    //Initialize google by using factory pattern over main class(SocialAuth)
                    $googleObj = SocialAuth::init( 'google' );
                    if ( $googleObj->validate() ) {
                        $identity = $googleObj->identity;
                        $attributes = $googleObj->getAttributes();
                        $email = $attributes['contact/email'];
                        $first_name = $attributes['namePerson/first'];
                        $last_name = $attributes['namePerson/last'];
                    }

                    $user_data = array(
                        'display_name' => $first_name . ' ' . $last_name,
                        'user_email' => $email
                    );

                    break;
            case 'linkedin':
                //Initialize linkedin by using factory pattern over main class(SocialAuth)
                $linkedinObj = SocialAuth::init( 'linkedin' );
                if ( isset( $_REQUEST['oauth_verifier'] ) ) {
                    $_SESSION['oauth_verifier'] = $_REQUEST['oauth_verifier'];

                    $linkedinObj->request_token = unserialize( $_SESSION['requestToken'] );
                    $linkedinObj->oauth_verifier = $_SESSION['oauth_verifier'];
                    $linkedinObj->getAccessToken( $_REQUEST['oauth_verifier'] );

                    $_SESSION['oauth_access_token'] = serialize( $linkedinObj->access_token );
                } else {
                    $linkedinObj->request_token = unserialize( $_SESSION['requestToken'] );
                    $linkedinObj->oauth_verifier = $_SESSION['oauth_verifier'];
                    $linkedinObj->access_token = unserialize( $_SESSION['oauth_access_token'] );
                }
                $response = (array)simplexml_load_string( $linkedinObj->getProfile("~:(id,site-public-profile-request,first-name,last-name,headline,picture-url)") );

                $user_data = array(
                        'display_name' => $response['first-name'] . ' ' . $response['last-name'],
                        'user_email' => 'l_' . $response['id']
                );
                break;
            case 'yahoo':
                //Initialize yahoo by using factory pattern over main class(SocialAuth)
                $yahooObj = SocialAuth::init( 'yahoo' );
                if ( $yahooObj->validate() ) {
                    $identity = $yahooObj->identity;
                    $attributes = $yahooObj->getAttributes();
                    $email = $attributes['contact/email'];
                    $first_name = $attributes['namePerson/first'];
                    $last_name = $attributes['namePerson/last'];
                }

                $user_data = array(
                        'display_name' => $first_name . ' ' . $last_name,
                        'user_email' => $email
                );
                break;
            default:
                SocialAuth::myRedirect( get_option( 'global_base_path' ) );

        }

        $user_info = get_user_by( 'login', $user_data['user_email'] );

        if ( $user_info ) {

        } else {
            $random_password = wp_generate_password( 12, false );


            $user_id = wp_create_user( $user_data['user_email'], $random_password, $user_data['user_email'] );
            $user_data['ID'] = $user_id;

            wp_update_user( array ('ID' => $user_id, 'display_name' => $user_data['display_name']) ) ;
            $user_info = get_user_by( 'email', $user_data['user_email'] );
        }
        if ( $user_info->ID ) {
            wp_set_auth_cookie( $user_info->ID );
            wp_set_current_user( $user_info->ID );
        }

        SocialAuth::myRedirect( get_option( 'global_base_path' ) );



    }
}


add_action( 'admin_menu', 'socialauth_admin_actions' );
add_action( 'plugins_loaded', 'socialauth_init' );
add_action( 'wp_head', 'check_login_state' );
add_action( 'wp_head', 'check_callback_state' );