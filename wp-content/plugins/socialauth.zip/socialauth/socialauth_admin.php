<?php
$expire_arr = array( 1 => "1 day",
                     2 => "2 days",
                     3 => "3 days",
                     7 => "1 week",
                     14 => "2 weeks",
                     30 => "1 month",
                     365 => "1 year" );
if( $_POST['socialauth_task'] == 'save_configuration' ) {
    foreach ( $_POST as $k => $v) {
        update_option( $k, $v );
    }
?>
<div class="updated"><p><strong><?php _e('Options saved.' ); ?></strong></p></div>
<?php
}
$global_base_path = get_option( 'global_base_path' );
$global_email_domain = get_option( 'global_email_domain' );
$global_expire_date = get_option( 'global_expire_date' );
$twitter_consumer_key = get_option( 'twitter_consumer_key' );
$twitter_consumer_secret = get_option( 'twitter_consumer_secret' );
$twitter_callback_url = get_option( 'twitter_callback_url' );
$twitter_logo_url = get_option( 'twitter_logo_url' );

$facebook_consumer_key = get_option( 'facebook_consumer_key' );
$facebook_consumer_secret = get_option( 'facebook_consumer_secret' );
$facebook_return_fields = get_option( 'facebook_return_fields' );
$facebook_permissions = get_option( 'facebook_permissions' );
$facebook_callback_url = get_option( 'facebook_callback_url' );
$facebook_logo_url = get_option( 'facebook_logo_url' );

$linkedin_consumer_key = get_option( 'linkedin_consumer_key' );
$linkedin_consumer_secret = get_option( 'linkedin_consumer_secret' );
$linkedin_callback_url = get_option( 'linkedin_callback_url' );
$linkedin_logo_url = get_option( 'linkedin_logo_url' );

$google_callback_url = get_option( 'google_callback_url' );
$google_logo_url = get_option( 'google_logo_url' );

$yahoo_callback_url = get_option( 'yahoo_callback_url' );
$yahoo_logo_url = get_option( 'yahoo_logo_url' );
?>
<?php    echo "<h2>" . __( 'Social Auth Configurations', 'socialauth_options' ) . "</h2>"; ?>
<form name="socialauth_admin_form" method="post" action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>">
    <input type="hidden" name="socialauth_task" value="save_configuration">
    <table>
        <tr>
            <td colspan="2"><?php    echo "<h4>" . __( 'Global Configurations', 'socialauth_options' ) . "</h4>"; ?></td>
        </tr>
        <tr><td colspan="2"><div><small style="color:gray;font-style: italic;">INFO: Base path of your application</small></div></td></tr>
        <tr>
            <td><?php _e( 'Base Path: ' ); ?></td><td><input type="text" name="global_base_path" value="<?php echo $global_base_path; ?>" size="70"></td>
        </tr>
        <tr><td colspan="2"><div><small style="color:gray;font-style: italic;">INFO: Domain name for email address for social networks that doesn't response user email address(twitter, linkedin)</small></div></td></tr>
        <tr>
            <td><?php _e( 'Email Address Domain: ' ); ?></td><td><input type="text" name="global_email_domain" value="<?php echo $global_email_domain; ?>" size="70"></td>
        </tr>
        <tr><td colspan="2"><div><small style="color:gray;font-style: italic;">INFO: Default cookie expire time</small></div></td></tr>
        <tr>
            <td><?php _e( 'Cookie Expire Time: ' ); ?></td>
            <td>
                <select name="global_expire_date">
                    <?php
                        foreach ( $expire_arr as $k => $v ) {
                            if ( $global_expire_date == $k ) {
                                echo '<option value="' . $k . '" SELECTED>' . $v . '</option>';
                            } else {
                                echo '<option value="' . $k . '">' . $v . '</option>';
                            }
                        }
                    ?>
                </select>
            </td>
        </tr>
        <tr>
            <td colspan="2"><?php    echo "<h4>" . __( 'Twitter Configurations', 'socialauth_options' ) . "</h4>"; ?></td>
        </tr>
        <tr><td colspan="2"><div><small style="color:gray;font-style: italic;">INFO: Twitter credentials</small></div></td></tr>
        <tr>
            <td><?php _e( 'Consumer Key: ' ); ?></td><td><input type="text" name="twitter_consumer_key" value="<?php echo $twitter_consumer_key; ?>" size="70"></td>
        </tr>
        <tr>
            <td><?php _e( 'Consumer Secret: ' ); ?></td><td><input type="text" name="twitter_consumer_secret" value="<?php echo $twitter_consumer_secret; ?>" size="70"></td>
        </tr>
        <tr><td colspan="2"><div><small style="color:gray;font-style: italic;">INFO: Callback url for twitter (http://yourwebsite.com/baspath/?type=twitter&callback=true)</small></div></td></tr>
        <tr>
            <td><?php _e( 'Callback Url: ' ); ?></td><td><input type="text" name="twitter_callback_url" value="<?php echo $twitter_callback_url; ?>" size="70"></td>
        </tr>
        <tr>
            <td><?php _e( 'Twitter Logo Url: ' ); ?></td><td><input type="text" name="twitter_logo_url" value="<?php echo $twitter_logo_url; ?>" size="70"></td>
        </tr>

        <tr>
            <td colspan="2"><?php    echo "<h4>" . __( 'Facebook Configurations', 'socialauth_options' ) . "</h4>"; ?></td>
        </tr>
        <tr><td colspan="2"><div><small style="color:gray;font-style: italic;">INFO: Facebook credentials</small></div></td></tr>
        <tr>
            <td><?php _e( 'Application ID: ' ); ?></td><td><input type="text" name="facebook_consumer_key" value="<?php echo $facebook_consumer_key; ?>" size="70"></td>
        </tr>
        <tr>
            <td><?php _e( 'Application Secret: ' ); ?></td><td><input type="text" name="facebook_consumer_secret" value="<?php echo $facebook_consumer_secret; ?>" size="70"></td>
        </tr>
        <tr><td colspan="2"><div><small style="color:gray;font-style: italic;">INFO: Facebook callback fields(default values, it can be empty).For full fields please refer to <a href="https://developers.facebook.com/docs/reference/api/user/" target="_blank">https://developers.facebook.com/docs/reference/api/user/</a></small></div></td></tr>
        <tr>
            <td><?php _e( 'Response Fields: ' ); ?></td><td><input type="text" name="facebook_return_fields" value="<?php echo $facebook_return_fields; ?>" size="70"></td>
        </tr>
        <tr><td colspan="2"><div><small style="color:gray;font-style: italic;">INFO: Facebook permissions(default values).For full permissions please refer to <a href="http://developers.facebook.com/docs/reference/api/permissions/" target="_blank">https://developers.facebook.com/docs/reference/api/user/</a></small></div></td></tr>
        <tr>
            <td><?php _e( 'Permissions: ' ); ?></td><td><input type="text" name="facebook_permissions" value="<?php echo $facebook_permissions; ?>" size="70"></td>
        </tr>
        <tr><td colspan="2"><div><small style="color:gray;font-style: italic;">INFO: Callback url for facebook (http://yourwebsite.com/baspath/?type=facebook&callback=true)</small></div></td></tr>
        <tr>
            <td><?php _e( 'Callback Url: ' ); ?></td><td><input type="text" name="facebook_callback_url" value="<?php echo $facebook_callback_url; ?>" size="70"></td>
        </tr>
        <tr>
            <td><?php _e( 'Facebook Logo Url: ' ); ?></td><td><input type="text" name="facebook_logo_url" value="<?php echo $facebook_logo_url; ?>" size="70"></td>
        </tr>

        <tr>
            <td colspan="2"><?php    echo "<h4>" . __( 'Linkedin Configurations', 'socialauth_options' ) . "</h4>"; ?></td>
        </tr>
        <tr><td colspan="2"><div><small style="color:gray;font-style: italic;">INFO: Linkedin credentials</small></div></td></tr>
        <tr>
            <td><?php _e( 'API Key: ' ); ?></td><td><input type="text" name="linkedin_consumer_key" value="<?php echo $linkedin_consumer_key; ?>" size="70"></td>
        </tr>
        <tr>
            <td><?php _e( 'Secret Key: ' ); ?></td><td><input type="text" name="linkedin_consumer_secret" value="<?php echo $linkedin_consumer_secret; ?>" size="70"></td>
        </tr>
        <tr><td colspan="2"><div><small style="color:gray;font-style: italic;">INFO: Callback url for linkedin (http://yourwebsite.com/baspath/?type=linkedin&callback=true)</small></div></td></tr>
        <tr>
            <td><?php _e( 'Callback Url: ' ); ?></td><td><input type="text" name="linkedin_callback_url" value="<?php echo $linkedin_callback_url; ?>" size="70"></td>
        </tr>
        <tr>
            <td><?php _e( 'Linkedin Logo Url: ' ); ?></td><td><input type="text" name="linkedin_logo_url" value="<?php echo $linkedin_logo_url; ?>" size="70"></td>
        </tr>

        <tr>
            <td colspan="2"><?php    echo "<h4>" . __( 'Google Configurations', 'socialauth_options' ) . "</h4>"; ?></td>
        </tr>
        <tr><td colspan="2"><div><small style="color:gray;font-style: italic;">INFO: Callback url for google (http://yourwebsite.com/baspath/?type=google&callback=true)</small></div></td></tr>
        <tr>
            <td><?php _e( 'Callback Url: ' ); ?></td><td><input type="text" name="google_callback_url" value="<?php echo $google_callback_url; ?>" size="70"></td>
        </tr>
        <tr>
            <td><?php _e( 'Google Logo Url: ' ); ?></td><td><input type="text" name="google_logo_url" value="<?php echo $google_logo_url; ?>" size="70"></td>
        </tr>

        <tr>
            <td colspan="2"><?php    echo "<h4>" . __( 'Yahoo Configurations', 'socialauth_options' ) . "</h4>"; ?></td>
        </tr>
        <tr><td colspan="2"><div><small style="color:gray;font-style: italic;">INFO: Callback url for yahoo (http://yourwebsite.com/baspath/?type=yahoo&callback=true)</small></div></td></tr>
        <tr>
            <td><?php _e( 'Callback Url: ' ); ?></td><td><input type="text" name="yahoo_callback_url" value="<?php echo $yahoo_callback_url; ?>" size="70"></td>
        </tr>
        <tr>
            <td><?php _e( 'Yahoo Logo Url: ' ); ?></td><td><input type="text" name="yahoo_logo_url" value="<?php echo $yahoo_logo_url; ?>" size="70"></td>
        </tr>
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="2"><input type="submit" name="submit" value="<?php _e('Save Changes', 'socialauth_options' ) ?>" /></td>
        </tr>
    </table>
</form>
