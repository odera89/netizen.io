You will use socialauth.zip inorder to install Social Auth.
